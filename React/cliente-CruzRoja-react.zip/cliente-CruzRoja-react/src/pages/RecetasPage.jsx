import React from "react";
import CrearReceta from "../components/CrearReceta";


const RecetasPage = () => {
  return (
    <div>
      <h1>Crear Receta</h1>
      <CrearReceta />
    </div>
  );
};

export default RecetasPage;
